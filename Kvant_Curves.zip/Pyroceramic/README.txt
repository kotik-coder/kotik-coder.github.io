Sample Name: Pyroceramic (Netzsch Standard)
Sample Thickness: 2.492 mm
Sample Diameter: 9.852 mm;
Density: 2574.0086 kg/m^3;

Pulse width: 1.5 ms
Pulse energy: 7 J
Pulse shape: RECTANGULAR
